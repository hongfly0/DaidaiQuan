<?php
/**
 * 配置文件
 */

return [
    // 数据库类型
    'type'     => 'mysql',
    // 服务器地址
    'hostname' => '47.106.37.216',
    // 数据库名
    'database' => 'daidaiquan',
    // 用户名
    'username' => 'fable',
    // 密码
    'password' => 'feng2163906@',
    // 端口
    'hostport' => '3306',
    // 数据库编码默认采用utf8
    'charset'  => 'utf8mb4',
    // 数据库表前缀
    'prefix'   => 'ddq_',
    "authcode" => 'NI3iHUB4jdZodhlOTG',
    //#COOKIE_PREFIX#
];
