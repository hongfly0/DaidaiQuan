<?php
/**
 * 配置文件
 */

return [
    'appKey'=>'CFFD4234D8C54E23CEE45C500F131367',
    'appSecret' => "ccc2e26a38e0473ab0e30c637c0d90bb",
    'accessToken' => "df42927b-6994-4ad3-8e25-e8fd0bb543b7"
];